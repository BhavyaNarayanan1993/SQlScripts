package com.training.ui;

import java.util.Collection;
import java.util.LinkedList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.training.model.Product;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequestMapping(value="/products")
public class ProductController {

		@GetMapping(value="/display")
		public String f1(Model model) {
			Product product=new Product(1011, "HP", 40000.00);
			model.addAttribute("prod", product);
			return "ProductDisplay";
		}
		
		@GetMapping(value="/listing")
		public String f2(Model model) {
			Product p1=new Product(1001, "HP", 40000.00);
			Product p2=new Product(1002, "Blackberry", 35000.00);
			Product p3=new Product(1003, "Sony TV", 34000.00);
			Product p4=new Product(1004, "LG washing machine", 67000.00);
			Product p5=new Product(1005, "LG Refrigerator", 67000.00);
			
			Collection<Product> products=new LinkedList<Product>();
			products.add(p1);
			products.add(p2);
			products.add(p3);
			products.add(p4);
			products.add(p5);
			model.addAttribute("prods", products);
			return "ProductListing";
		}
}
